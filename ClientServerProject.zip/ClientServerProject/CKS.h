#include "C2S.h"
#include "C1K.h"

char * processString(char *string)
{
        char *tempString;
        tempString=(char *)malloc(9*sizeof(char));
        memset(tempString,'\0',8);
        memcpy(tempString,string,8);
        tempString[8]='\0';
        return tempString;
}
char * processAnyString(char *string)
{
        char *tempString;
        tempString=(char *)malloc(101*sizeof(char));
        memset(tempString,'\0',100);
        memcpy(tempString,string,100);
        tempString[100]='\0';
        return tempString;
}

void printRequestSP(Request req)
{
        printf("request.length = %d\n",req.length);
        printf("request.C = %s\n",processString(req.C));
       	printf("Encrypted Argument=");
        int indLen;
        for(indLen=0;indLen<req.argument.encLen;indLen++)
        {
                printf("%03d ",(int)req.argument.encMsg[indLen]);
        }
       	printf("\nEncrypted Token=");
        for(indLen=0;indLen<req.token.encLen;indLen++)
        {
                printf("%03d ",(int)req.token.encMsg[indLen]);
        }
 
}
int printReplySP(Reply reply)
{
        printf("Length=%d\n",reply.len);
        printf("reply.C=%s\n",processString(reply.C));
        printf("reply.S=%s\n",processString(reply.S));
        printf("reply.str.length=%d\n",reply.str.len);
        printf("reply.str.str=%s\n",processAnyString(reply.str.str));
        return 0;
}
int errorReplySP(EncReplySPStruct *encReply)
{
        encReply->encLen=-1;
	return 0;
}
void printEncryptedReply(unsigned int encLen,unsigned char *encMsg)
{
        int indLen;
        printf("\n\n---------Encrypted Reply----------\n");
        for(indLen=0;indLen<encLen;indLen++)
        {
                printf("%03d ",(int)encMsg[indLen]);
        }
        printf("\n");
        printf("---------------------------------------\n");
}
void printSessionKey(char *KCS)
{
	int i;
	for(i=0;i<8;i++)
		printf("%03d ",(int)KCS[i]);

}

