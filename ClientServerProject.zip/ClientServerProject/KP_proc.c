#include<rpc/rpc.h>
#include<stdio.h>
#include<stdlib.h>
#include <string.h>
#include "C1K.h"
#include "CKS.h"
#include "global.h"
#include "rsaref.h"
#include <md5.h>

#define DBFILE "DB.key" 

int KP_validator(char *id,char *keyId)
{
        int result=-1,strLen=50;
	char Key[8];
	char keyValue[17];
	memset(keyValue,'\0',17);
        //Checking for validity of C and S
        //0 is true and 1 is false
	FILE *DB;
	DB = fopen(DBFILE,"r");
	if(DB == NULL)
	{
		perror("Error Opening File ");
		return 1;
	}
	while(fgets(keyValue,17,DB)!=NULL)
	{
		if(strlen(keyValue)!=0)
		{
			memcpy(Key,keyValue,8);
			if(memcmp(id,Key,8)==0)
			{
				memcpy(keyId,keyValue+8,8);
				result=0;
				break;
			}
			memset(Key,'\0',8);
		}
	}
	fclose(DB);
        return result;
}
int printMessage(struct netReply *reply)
{
        printf("--------------Reply-----------------\n");
        printf("Length=%d\n",reply->len);
        printf("reply.R.C=%s\n",processString(reply->R.C));
        printf("reply.R.S=%s\n",processString(reply->R.S));
        printf("reply.R.Key=");
	printSessionKey(reply->R.Key);
        printf("\nEncrypted Token=");
        int indLen;
        for(indLen=0;indLen<reply->R.token.encLen;indLen++)
        {
                printf("%03d ",(int)reply->R.token.encMsg[indLen]);
        }
        printf("\n");
        printf("---------------------------------------\n");

}

int keyGen(char *KCS,struct reply *rep)
{

	FILE *dt, *popen();
 	unsigned char text[128], randText[128];
 	dt = popen("date; ps -e", "r");
 	fread(text, 128, 1, dt);
 	md5_calc(randText, text, 128);
 	memcpy(KCS, randText, 8);
 	pclose(dt);
	//memcpy(KCS,"qwertyas",8);
	memset(rep->Key,'\0',8);
	memcpy(rep->Key,KCS,8);
	return 0;
}
int encryptToken(struct Token token,struct EncTokenStruct *encToken,char *Key)
{
        unsigned char encryptedBlock[1000];
        unsigned char temString[1000];
        unsigned int encryptedBlockLen;
        unsigned char iv[8];
        memset(iv, '\0', 8);
        memcpy(temString,(unsigned char*) &token,sizeof(token));
        R_EncryptPEMBlock(encryptedBlock,&encryptedBlockLen,temString,sizeof(token),Key,iv);
        if(encryptedBlockLen==0)
        {
                printf("Error while encrypting\n");
                return -1;
        }
        encToken->encLen=encryptedBlockLen;
        memcpy(encToken->encMsg,encryptedBlock,encryptedBlockLen);
        return 0;
}

int token_builder(struct request req,struct reply *rep,char *KCS,char *KeyS)
{
	struct Token token;	
	struct EncTokenStruct encToken;
	memset(token.C,'\0',8);
	memset(token.S,'\0',8);
	memset(token.Key,'\0',8);
	memcpy(token.C,req.C,strlen(processString(req.C)));
	memcpy(token.S,req.S,strlen(processString(req.S)));
	memcpy(token.Key,KCS,strlen(processString(KCS)));
	encryptToken(token,&encToken,KeyS);
	rep->token=encToken;
	return 0;
}
int replyBuilder(struct netReply *reply ,struct reply rep,struct request req)
{
	memset(rep.C,'\0',8);
	memset(rep.S,'\0',8);
	memcpy(rep.C,req.C,8);
	memcpy(rep.S,req.S,8);
	reply->R = rep;	
	reply->len = strlen(processString(rep.C))+strlen(processString(rep.S))+strlen(processString(rep.Key))+rep.token.encLen; 
	return 0;
}
int errorReply(struct EncReplyStruct *encReply)
{
	encReply->encLen = -1;
	return 0;
}
int encryptReply(struct netReply reply,struct EncReplyStruct *encReply,char *Key)
{
	unsigned char encryptedBlock[1000];
	unsigned char temString[1000];
        unsigned int encryptedBlockLen;
	unsigned char iv[8];
	memset(iv, '\0', 8);
	memcpy(temString,(unsigned char*) &reply,sizeof(reply));
	R_EncryptPEMBlock(encryptedBlock,&encryptedBlockLen,temString,sizeof(reply),Key,iv);
	if(encryptedBlockLen==0)
	{
		printf("Error while encrypting\n");
		return -1;
	}
	encReply->encLen=encryptedBlockLen;
        memcpy(encReply->encMsg,encryptedBlock,encryptedBlockLen);
	return 0;	
}
void setErrorReply(struct EncReplyStruct *encReply)
{
	errorReply(encReply);
}
EncReplyStruct* requestsessionkey_1(request req)
{
	struct reply rep;
	struct netReply reply;
	static struct EncReplyStruct encReply;
	char KCS[8];
	char keyC[8],keyS[8];
	printf("\n\n-----Request received from Client------\n");
	printf("request length=%d\nClientid=%s\nServerid=%s\n",req.len,processString(req.C),processString(req.S));
	printf("---------------------------------------\n");
	if(KP_validator(req.C,keyC)!=0)
	{
		setErrorReply(&encReply);
		return &encReply ;
	}
	else
		printf("Client Id :Validation Successful!!!!\n");	
	if(KP_validator(req.S,keyS)!=0)
	{
		setErrorReply(&encReply);
		return &encReply ;
	}
	else
		printf("Server Id :Validation Successful!!!!\n");	
	if(keyGen(KCS,&rep)!=0)
	{
		setErrorReply(&encReply);
		return &encReply ;
	}
	else
		printf("KCS generated Successfully\n");
	if(token_builder(req,&rep,KCS,keyS)!=0)
	{
		setErrorReply(&encReply);
		return &encReply ;
	}
	if(replyBuilder(&reply,rep,req)!=0)	
	{
		setErrorReply(&encReply);
		return &encReply ;
	}
	encryptReply(reply,&encReply,keyC);
	printMessage(&reply);
	printEncryptedReply(encReply.encLen,encReply.encMsg);
	return &encReply;
}

