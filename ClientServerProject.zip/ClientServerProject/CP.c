/* clientC1k.c */
#include <stdio.h>
#include <rpc/rpc.h> 
#include "C2S.h"
#include "C1K.h"
#include "CKS.h"
#include "Ckey.h"
#include <stdlib.h>
#include <string.h>
#include "global.h"
#include "rsaref.h"
#include <md5.h>

int requestBuilder(char *argv[],struct request *req)
{
	memset(req->C,'\0',8);	
	memset(req->S,'\0',8);	
	memcpy(req->C,argv[1],8);
	memcpy(req->S,argv[2],8);
	req->len=strlen(processString(req->C))+strlen(processString(req->S));
	return 0;

}
int printMessage(struct netReply *reply)
{
        printf("----------Decrypted Reply-----------------\n");
        printf("Length=%d\n",reply->len);
        printf("reply.R.C=%s\n",processString(reply->R.C));
        printf("reply.R.S=%s\n",processString(reply->R.S));
        printf("reply.R.Key=");
	printSessionKey(reply->R.Key);
        printf("\nEncrypted Token=");
        int indLen;
        for(indLen=0;indLen<reply->R.token.encLen;indLen++)
        {
                printf("%03d ",(int)reply->R.token.encMsg[indLen]);
        }
        printf("\n");
        printf("---------------------------------------\n");

}

char * promptUser()
{
        char *str;
        str =(char *)malloc(100*sizeof(char));
        printf("Enter Message = ");
        scanf("%s",str);
        return str;
}
int requestBuilderSP(struct Request * request,struct EncArgSPStruct stringSP,struct EncTokenSPStruct token,char *C)
{
        int length=0;
        memset(request->C,'\0',8);
        memcpy(request->C,C,8);
        request->argument=stringSP;
        request->token=token;
	length=strlen(processString(request->C)) +  stringSP.encLen + token.encLen;
        request->length=length;
        return 0;
}
int buildTokenSP(struct EncTokenSPStruct *token,struct EncTokenStruct tokenObj)
{
	token->encLen=tokenObj.encLen;
	memcpy(token->encMsg,tokenObj.encMsg,tokenObj.encLen);
        return 0;
}
int decrypt(unsigned char *decryptedBlock,unsigned int *decryptedBlockLen,char *Key,unsigned int encLen,unsigned char *encMsg)
{
        unsigned char iv[8];
        memset(iv, '\0', 8);
        R_DecryptPEMBlock(decryptedBlock,decryptedBlockLen,encMsg,encLen,Key,iv);
        if(decryptedBlockLen==0)
        {
                printf("Error while decrypting\n");
                return -1;
        }
        return 0;
}
struct netReply decryptReplyKP(struct EncReplyStruct *encReply,char *Key)
{
	struct netReply reply;
        unsigned char decryptedBlock[100];
        unsigned int decryptedBlockLen;
        decrypt(decryptedBlock,&decryptedBlockLen,Key,encReply->encLen,encReply->encMsg);
        memcpy((unsigned char*)&reply,decryptedBlock,decryptedBlockLen);
        return reply;
}
int encryptArgumentSP(char *string,struct EncArgSPStruct *encArg,char *Key)
{
        unsigned char encryptedBlock[1000];
        unsigned int encryptedBlockLen;
	unsigned char temString[1000];
	struct String stringSP;
        unsigned char iv[8];
        memset(iv, '\0', 8);
	stringSP.len=strlen(string);
	strcpy(stringSP.str,string);
	memcpy(temString,(unsigned char*) &stringSP,sizeof(stringSP));
        R_EncryptPEMBlock(encryptedBlock,&encryptedBlockLen,temString,sizeof(stringSP),Key,iv);
        if(encryptedBlockLen==0)
        {
                printf("Error while encrypting\n");
                return -1;
        }
        encArg->encLen=encryptedBlockLen;
        strcpy(encArg->encMsg,encryptedBlock);
	/*int indLen;
        printf("\n\n---------Encrypted Argument----------\n");
        for(indLen=0;indLen<encArg->encLen;indLen++)
        {
                printf("%03d ",(int)encArg->encMsg[indLen]);
        }
        printf("\n");
        printf("---------------------------------------\n");
	*/	
        return 0;
}

struct Reply decryptReplySP(struct EncReplySPStruct *encReply,char *Key)
{
        struct Reply reply;
        unsigned char decryptedBlock[1000];
        unsigned int decryptedBlockLen;
        decrypt(decryptedBlock,&decryptedBlockLen,Key,encReply->encLen,encReply->encMsg);
        memcpy((unsigned char*)&reply,decryptedBlock,decryptedBlockLen);
        return reply;
}

int main(int argc,char * argv[])
{
        system("clear");
	CLIENT *keyServer,*appServer;
	char *serverK,*serverA;
	char hostName[8];
	struct request req;
	struct netReply *reply;
	struct netReply replyKP;
	struct EncReplyStruct *encReply;
	if(argc!=5)
	{
		printf("Error in command Line format\n ");
		exit(2);
	}
	serverK = argv[3];
	serverA = argv[4]; 
        if((keyServer=clnt_create(serverK,IT_PROG,AS_VERS,"udp"))==NULL) 
	{
        	clnt_pcreateerror(serverK);
        	exit(2);
        }
	memcpy(hostName,argv[3],8);
	if(requestBuilder(argv,&req)!=0)
	{
		printf("Error while building request!\n ");
		exit(2);
	}
	printf("\n\n-----Sending request to KP Server------\n");
	printf("request length=%d \nCleintid=%s \nServerid=%s\n",req.len,processString(req.C),processString(req.S));
	printf("--------------Request Sent-------------\n\n");
	/* Calling service procedure */
	encReply=requestsessionkey_1(req,keyServer);
	if(encReply==NULL)
	{
		clnt_perror(keyServer, "call failed");
		exit(3);
	}
	printf("\n-----Reply received from KP Server------\n");
	if(encReply->encLen == -1)
	{
		printf("Error message received!!!\n");
		exit(2);
	}
	else
	{
		replyKP=decryptReplyKP(encReply,key);
                printEncryptedReply(encReply->encLen,encReply->encMsg);
                printMessage(&replyKP);
        }


	//A2
        struct Request request;
	struct EncTokenSPStruct encToken;
        //struct String stringSP;
        struct EncArgSPStruct encArg;
        struct Reply replySP;
	struct EncReplySPStruct *encReplySP;

        serverA=argv[3];

        //client connection
	if((appServer=clnt_create(serverA,ITSP_PROG,SP_VERS,"udp"))==NULL)
        {
                clnt_pcreateerror(serverA);
                //exit(2);
                return 2;
        }


        //display options
        char choice[10];
        memset(choice,'\0',10);
        int option=-1;
        while(1)
        {
                printf("-----------Available Services----------\n");
                printf("1 . Enter 1 for Alpha\n");
                printf("2 . ENter 2 for Numeric\n");
                printf("---------------------------\n\n");
                printf("Enter your Choice: ");
                scanf("%s", choice);
                option = atoi(choice);
                if(option!=1 && option!=2)
                {
			//Invalid Input
                        printf("Invalid Choice. Please re-try..\n");
                }
                else
                        break;
        }
        char * string1=promptUser();
	encryptArgumentSP(string1,&encArg,replyKP.R.Key);
	buildTokenSP(&encToken,replyKP.R.token);
	requestBuilderSP(&request,encArg,encToken,argv[1]);
        printf("\n\n--------Sending Request to application--------\n");
        printRequestSP(request);
        printf("\n-------------------------------------------\n\n");
        if(option == 1)
        {
                encReplySP=alpha_1(request,appServer);
        }
        if(option ==2)
        {
                encReplySP=numeric_1(request,appServer);
        }
        if(encReplySP==NULL)
        {
                clnt_perror(appServer,"Call Failed");
                exit(2);
        }
        if(encReplySP->encLen==-1)
                printf("Error received from the application!!\n");
        else
        {
		printf("\n\n--------Reply Received from application--------\n");
                replySP=decryptReplySP(encReplySP,replyKP.R.Key);
                printEncryptedReply(encReplySP->encLen,encReplySP->encMsg);
                printReplySP(replySP);
                printf("\n-------------------------------------------");
                printf("\n-------------------------------------------\n\n");
        }


	clnt_destroy(appServer);               /* done with the handle */
	clnt_destroy(keyServer);               /* done with the handle */
	exit(0);
}
