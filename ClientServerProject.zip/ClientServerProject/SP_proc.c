#include<stdio.h>
#include<stdlib.h>
#include<rpc/rpc.h>
#include<string.h>
#include "C2S.h"
#include "CKS.h"
#include "Skey.h"
#include "global.h"
#include "rsaref.h"
#include <md5.h>

int decrypt(char *decryptedBlock,int *decryptedBlockLen,char *Key,int encLen,char *encMsg)
{
        unsigned char iv[8];
        memset(iv, '\0', 8);
        R_DecryptPEMBlock(decryptedBlock,decryptedBlockLen,encMsg,encLen,Key,iv);
        if(decryptedBlockLen==0)
        {
                printf("Error while decrypting\n");
                return -1;
        }
        return 0;
}

int decryptToken(struct EncTokenSPStruct encToken,struct TokenSP *token,char *Key)	
{
        unsigned char decryptedBlock[1000];
        unsigned int decryptedBlockLen;
        if(decrypt(decryptedBlock,&decryptedBlockLen,Key,encToken.encLen,encToken.encMsg)!=0)
		return -1;
        memcpy((unsigned char*)token,decryptedBlock,decryptedBlockLen);
        return 0;

}
void printDecryptedArg(struct String *arg)
{
	printf("\n----------Decrypted Argument-----------\n");
	printf("String length = %d\n",arg->len);	
	printf("String message = %s\n",arg->str);	
	printf("\n--------------------------------------\n\n");
}
int decryptArg(struct EncArgSPStruct encArg,struct String *arg,char *Key)
{
	unsigned char decryptedBlock[1000];
        unsigned int decryptedBlockLen;
        if(decrypt(decryptedBlock,&decryptedBlockLen,Key,encArg.encLen,encArg.encMsg)!=0)
                return -1;
        memcpy((unsigned char*)arg,decryptedBlock,decryptedBlockLen);
	printDecryptedArg(arg);
        return 0;
}
int encryptReply(struct EncReplySPStruct *encReply,struct Reply reply,char *Key)
{
	
	unsigned char encryptedBlock[1000];
        unsigned int encryptedBlockLen;
        unsigned char iv[8];
	unsigned char temString[1000];
        memset(iv, '\0', 8);
	memcpy(temString,(unsigned char*) &reply,sizeof(reply));
	R_EncryptPEMBlock(encryptedBlock,&encryptedBlockLen,temString,sizeof(reply),Key,iv);
        if(encryptedBlockLen==0)
        {
                printf("Error while encrypting\n");
                return -1;
        }
        encReply->encLen=encryptedBlockLen;
        strcpy(encReply->encMsg,encryptedBlock);
        return 0;
}
void printDecryptedToken(struct TokenSP *token)
{
	printf("\n---------Decrypted Token-----------\n");
	printf("token.C = %s\n",processString(token->C));
	printf("token.S = %s\n",processString(token->S));
	printf("Session Key=");
	printSessionKey(token->Key);
	printf("\n--------------------------------------\n\n");
}
int SP_Validator(struct Request request,struct TokenSP *token,char *Key)
{
	printf("\n------------SP Validator output-------------\n\n");
	//Checking for validity of sender and parses token 
        //0 is true and 1 is false
	if(decryptToken(request.token,token,Key)!=0)
		return -1;	
	printDecryptedToken(token);
	if(memcmp(request.C,token->C,8)!=0)
	{
		printf("Client Id is NOT matching with token.Request is IN-Valid\n");
	printf("\n-------------------------------------------\n\n");
		return -1;
	}
	else
	{
		printf("Client is Matching with token.Request is Valid\n");
	printf("\n-------------------------------------------\n\n");
		return 0;
	}
}
//reply builder build the response which is sent to Client
int replyBuilder(struct Reply *reply,struct String stringSP,struct TokenSP token)
{
	int length=0;
	memset(reply->C,'\0',8);
	memset(reply->S,'\0',8);
	memcpy(reply->C,token.C,8);
	memcpy(reply->S,token.S,8);
	reply->str=stringSP;
	length=strlen(processString(reply->C)) + strlen(processString(reply->S))+stringSP.len;
	reply->len=length;
	return 0;
}

//service procedure
EncReplySPStruct * alpha_1(Request req)
{
	int i=0,ind=0;
	char *resultString;
	static struct EncReplySPStruct encReply;
	struct Reply reply;
	struct String stringSP;
	struct String arg;
	struct TokenSP token;

	printf("\n\n--------Request Received from Client--------\n");
	printRequestSP(req);
	printf("\n-------------------------------------------\n\n");
	if(SP_Validator(req,&token,key)!=0)
	{
		errorReplySP(&encReply);
		return(&encReply);
	}
	decryptArg(req.argument,&arg,token.Key);
	resultString = (char*)malloc((arg.len + 1)*sizeof(char));
	if(resultString==NULL)
	{
		printf("Error while allocating memory\n");
	}	
	memset(resultString,'\0',arg.len+1);
	while(arg.str[i]!='\0')
	{
		if((arg.str[i]>=65 && arg.str[i]<=90) || (arg.str[i]>=97 && arg.str[i] <=122))
		{
			resultString[ind++]=arg.str[i];
		}
	i++;	
	}
	stringSP.len=strlen(resultString);
	strncpy(stringSP.str,resultString,ind);
	if(replyBuilder(&reply,stringSP,token)!=0)
	{		
		errorReplySP(&encReply);
		return &encReply;
	}
	encryptReply(&encReply,reply,token.Key);
	printf("\n\n---------Sending Reply to Client------\n");
	printReplySP(reply);
	printf("\n\n---------Encrypted Reply ------\n");
	printEncryptedReply(encReply.encLen,encReply.encMsg);	
	printf("\n-------------Reply Sent----------------\n");
	printf("-------------------------------------------\n\n");
return &encReply;	
}

//service procedure
EncReplySPStruct * numeric_1(Request req)
{
	int i=0,ind=0;
        char *resultString;
	static struct EncReplySPStruct encReply;
	struct Reply reply;
	struct String stringSP;
	struct String arg;
	struct TokenSP token;

	printf("\n\n--------Request Received from Client--------\n");
        printRequestSP(req);
        printf("\n-------------------------------------------\n\n");
	if(SP_Validator(req,&token,key)!=0)
        {
                errorReplySP(&encReply);
                return(&encReply);
        }
	decryptArg(req.argument,&arg,token.Key);
        resultString = (char*)malloc((arg.len+1)*sizeof(char));
	if(resultString==NULL)
        {
                printf("Error while allocating memory\n");
        }
        memset(resultString,'\0',arg.len+1);
        while(arg.str[i]!='\0')
        {
                if(arg.str[i]>=48 && arg.str[i]<=57)
                {
                        resultString[ind++]=arg.str[i];
                }
        i++;
        }
	stringSP.len=strlen(resultString);
	strcpy(stringSP.str,resultString);
	if(replyBuilder(&reply,stringSP,token)!=0)
        {
                errorReplySP(&encReply);
                return &encReply;
        }
	encryptReply(&encReply,reply,token.Key);
	printf("\n\n---------Sending Reply to Client------\n");
	printReplySP(reply);
        printEncryptedReply(encReply.encLen,encReply.encMsg);
	printf("\n-------------Reply Sent----------------\n");
	printf("---------------------------------------\n\n");
return &encReply;
}
