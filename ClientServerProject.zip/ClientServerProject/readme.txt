Requirements: GCC and UNIX
1. Run "make all" to get CP, SERVER_CK and SERVER_CS.
2. Run CP, SERVER_CK and SERVER_CS on different instances.
3. CP- Client, SERVER_CS- Application server & SERVER_CK- Key Server.
4. Run "make clean" to clear build after run.
	
