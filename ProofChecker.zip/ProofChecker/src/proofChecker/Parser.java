/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proofChecker;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author Rishmit
 */
public class Parser {

    final private static String LPAREN = "(";
    final private static String RPAREN = ")";
    static int lineNumber;
    /*static ArrayList<Object> theorem;
    static int it;*/
    static{
        lineNumber=-9999;
        
    }
    
    /*
     parseTheorem(L):
     s := L[2]
     A := parseArgument(L[3:len(L)­1])
     return ["t", s, A]
     */
    public static ArrayList<Object> parseTheorem(List<String> tokens) {
        ArrayList<Object> arg = parseArgument(tokens.subList(3, tokens.size() - 1));
        ArrayList<Object> theorem = new ArrayList<>();
        int it=0;
        //System.out.println("\n---------------------------------------");
        //System.out.println("arg in parseTheorem: " + arg);
        //System.out.println("\n---------------------------------------");
        theorem.add(it++, "\"t\"");
        theorem.add(it++,tokens.get(2));
        theorem.add(it++,arg);
        return theorem;
    }

    /*
     parseArgument(L)
     A,i := [], 1
     while L[i] != RPAREN:
     A := A+[parse(L[i:nextExp(i)])]
     i := extExp(L,i)
     return A
     */
    public static ArrayList<Object> parseArgument(List<String> argList) {
        ArrayList<Object> arg = new ArrayList<Object>();
        int index = 1;
        while (index < argList.size() && (!(argList.get(index)).equals(RPAREN))) {
            int nextExpIndex = getNextExpression(argList, index);
            arg.add(parse(argList.subList(index, nextExpIndex)));
            //System.out.println(index + " " + nextExpIndex);
            index = nextExpIndex;
        }
        //System.out.println("\n---------------------------------------");
        //System.out.println("parseArgument: " + arg);
        //System.out.println("\n---------------------------------------");
        return arg;
    }
    /*
     gets the next expressions index from the current position
     */

    private static int getNextExpression(List<String> argList, int i) {

        if (argList.get(i).equals(LPAREN)) {
            int index, counter = 0;
            for (index = i; index < argList.size(); index++) {
                if (argList.get(index).equals(LPAREN)) {
                    counter++;
                } else if (argList.get(index).equals(RPAREN)) {
                    counter--;
                    if (counter == 0) {
                        break;
                    }

                }
            }
            return index + 1;
        } else {
            return i + 1;
        }

    }
    /*
     parse(e):
     if isTheorem(e) : return parseTheorem(e)
     if isAssertion(e) : return parseAssertion(e)
     if isSupposition(e): return e
     */

    public static Object parse(List<String> subList) {
        Object parsedText = null;

        if (subList.size() > 1) {
            if (subList.get(1).equalsIgnoreCase("\"t\"")) {
                //Theorem
                parsedText = parseTheorem(subList);
            }
            if (subList.get(1).equalsIgnoreCase("\"a\"")) {
                //Assertion
                parsedText = parseAssertion(subList);

            }
        } else if (subList.get(0).toLowerCase().startsWith("\"Suppose".toLowerCase())) {
            //Supposition
            parsedText = subList.get(0);
        }
        return parsedText;
    }
    /*
     parseAssertion(e):
     s := e[2]
     J := parseJustification(e[3:len(e)­1])
     return ("a", s, J)
     */

    public static ArrayList<Object> parseAssertion(List<String> list) {
        int i=0;
        List<String> justification = parseJustification(list.subList(3, list.size() - 1));
        ArrayList<Object> assertion = new ArrayList<Object>();
        assertion.add(i++, "\"a\"");
        assertion.add(i++,list.get(2));
        assertion.add(i++, justification);
        //Assertion assertion = new Assertion("\"a\"", list.get(2), justification);
        return assertion;
    }
    /*
     parseJustification(L): return L[1:len(L)­1]
     */

    public static List<String> parseJustification(List<String> list) {
        return list.subList(1, list.size() - 1);
    }
    /*
     argLength(A):
     L=0
     for e in A:
     L=L+componentLength(A)
     return L
    
     ArrayList<Object> theoremList=theorem.getTheorem();
     */

    public static int getArgLength(Object theoObject) {
        int len = 0;
    //System.out.println("\n---------------------------------------");
        for (int i = 0; i < ((List<Object>)theoObject).size(); i++) {
            
            //System.out.println("get arglength i ----------"+i+" "+((List<Object>)theoObject).get(i));
            len =len+ getComponentLength(((List<Object>)theoObject).get(i));
        }
        //System.out.println("\n-----------------len----------------------"+len);
        return len;
    }
    /*
     componentLength(e):
     if isSupposition(e): return 1
     if assertion(e): return 1
     if theorem(e): return argLength(e[1])+1
     */

    public static int getComponentLength(Object obj) {

        int compLen = 0;
        //System.out.println("obj: "+((List<Object>) obj).get(0));
        if (obj.toString().toLowerCase().startsWith("\"suppose")) {
        //Supposition
            //System.out.println("if suppose: "+obj);
            compLen = 1;
        } else {
            //System.out.println("else "+((List<Object>) obj).get(0));
            if (((List<Object>) obj).get(0).equals("\"a\"")) {
                //Assertion
                //System.out.println("if assertion: "+obj);
                compLen = 1;
            }
            if (((List<Object>) obj).get(0).equals("\"t\"")) {
                //System.out.println("Theorem");
                compLen = getArgLength(((List<Object>) obj).get(2)) + 1;
            }
        }
        //System.out.println("comp length========== "+compLen);
        return compLen;
    }
    
    /*
    numberToNested(A, n):
        Given an argument and a nonnegative integer n, less than or argLength(A), numberToNested is
        a list [n1,...nk] such that the n'th step of argument A is A[n1]...[nk].  For example, 
        ● numToNested(A,3) = [1,1,0] since line 3 above is really A[1][2][0]
        ● numToNestedI(A,2) = [1,1], since line 2 is A[1][1]
        ● numToNested(A,4) = [1,2,1], since line 4 is A[1][2][1]
    */
    public static ArrayList<Integer> getNumberToNested(ArrayList<Object> arg, int n)
    {
        //System.out.println("number to nested="+arg);
        //System.out.println("number n "+n);
        
          
        ArrayList<Integer> numList = new ArrayList<>();
        if(lineNumber<=getArgLength(arg))
        {
            if(lineNumber==-9999)
                lineNumber=n;  
            for(int i=0;i<arg.size();i++)
            {
                if (arg.get(i).toString().toLowerCase().startsWith("\"suppose")) 
                {
                    lineNumber--;
                //    System.out.println(lineNumber);
                    if(lineNumber==0 ||lineNumber==-9999)
                    {
                        numList.add(i);
                        lineNumber=-9999;
                        break;
                    }
                }
                else
                {
              //      System.out.println((List<Object>) arg.get(i));
                    if (((List<Object>) arg.get(i)).get(0).equals("\"a\"")) 
                    {
                        lineNumber--;//System.out.println(lineNumber);
                        if(lineNumber==0 || lineNumber==-9999)
                        {
                            numList.add(i);
                            lineNumber=-9999;
                            break;
                        }

                    }
                    if (((List<Object>) arg.get(i)).get(0).equals("\"t\"")) 
                    {
                        lineNumber--;//decremented for statement
            //            System.out.println(lineNumber);
                        if(lineNumber==0)
                        {
                            numList.add(i);
                            numList.add(1);//1 for statement
                            break;
                        }
                        ArrayList<Integer> tempNumList=getNumberToNested((ArrayList<Object>)(((ArrayList<Object>)(arg.get(i))).get(2)),lineNumber);
                        if(!tempNumList.isEmpty())
                        {
                        numList.add(i);
                        numList.add(2);
                            for(Integer x:tempNumList)
                            {
                                numList.add(x);
          //                      System.out.println("numList ="+numList);
                            }
                            if(lineNumber==0 || lineNumber==-9999)
                            {
                                lineNumber=-9999;
                                break;
                            }
                        }
                    }
                }
                
            }
            
        }
        else
        {
            lineNumber -=getArgLength(arg);
        }
        //System.out.println(lineNumber);
        if(lineNumber==0 || lineNumber==-9999)
        {
            lineNumber=-9999;
         return numList;
        }
        else
            return new ArrayList<Integer>();//return temp List
    }
    
    /*
        indexNested(A,N):
        if N ==[k], return A[k]
        front = N[0:len(N)­1]
        back= N[len(N)­1]
        return indexNested(A,front) [back]
     */
    public static Object indexNested(ArrayList<Object> a, List<Integer> numList)
    {
        Object arrStr  = new Object();
        if(numList.size()==1)
        {
            arrStr=a.get(numList.get(0));
        }
        else
        {
            List<Integer> front = (List<Integer>)(numList.subList(0, numList.size()-1));
            int back = numList.get(numList.size()-1);
            arrStr=(((ArrayList<Object>)(indexNested(a,front))).get(back));
        }
        //System.out.println("Index Nested Output===>"+arrStr);
        return arrStr;
    }
    /*
        index(A,n):
        return indexNested(A,numberToNested(A,n))
    */
    public static Object index(ArrayList<Object> a, int n)
    {
        //System.out.println("index ="+indexNested(a,getNumberToNested(a, n)));
        //System.out.println("n="+n);
        //System.out.println("a= "+a);
        ArrayList<Integer> numList = getNumberToNested(a, n);
        //.out.println("numlist inside index: "+getNumberToNested(a, n));
        return indexNested(a,numList);
    }
    /*
        Justifications(A,n):
       line = index(A,n)
       if line is not an assertion, return [ ]
       if line is an assertion, return the number of integers in line[1]
    */
    public static List<String> getJustifications(ArrayList<Object> a, int n)
    {
        Object line = index(a,n);
        if (line.toString().toLowerCase().startsWith("\"suppose")) {
            return new ArrayList<String>();//return empty list
        }
        else
        {
            if (line.toString().toLowerCase().startsWith("[\"a\"")) 
            {
                //System.out.println("line "+line);
                return  ((List<String>)((ArrayList<Object>)line).get(2));
            }
            else
            {
                return new ArrayList<String>();//return empty list
            }
        }
        
    }
    /*
        suppositionsOf(A):
        L = [ ]
        for i in range(0,arglength(A)):
        if A[i] is a supposition:
        L=L+[i]
        */
    public static ArrayList<Object> suppositionsOf(List<Object> a)
    {
        //System.out.println("supposition of "+a);
        ArrayList<Object> suppList = new ArrayList<>();
        for(int i=0;i<a.size();i++)
        {
            if (a.get(i).toString().toLowerCase().startsWith("\"suppose"))
                suppList.add(a.get(i));
        }
        //System.out.println("supplits "+suppList);
        return suppList;
    }
    /*
        suppositionsInForce(A,n):
        N = numberToNested(A,n)
        Ms = initSegs(N)  # the proper initial segments of N
        L=[ ]
        for M in Ms:
        L=L+suppositionsOf(M)
    */
    
    public static ArrayList<String> suppositionsInForce(ArrayList<Object> arg,int n)
    {
    ArrayList<String> sup=new ArrayList<String>();
    ArrayList<Object> argList=new ArrayList<Object>(arg);
    
    ArrayList<Integer> numList=getNumberToNested(argList,n);
        //System.out.println("numlist=>"+numList);
    if(numList.size()>0)
    {
    for(int i=0;i<numList.size()-1;i++)
    {
        for(int j=0;j<numList.get(i);j++)
        {
            if((argList.get(j)).toString().toLowerCase().startsWith("\"suppose"))
            {
                sup.add(argList.get(j).toString());
            }
        }
        argList=(ArrayList<Object>)indexNested(arg,numList.subList(0,i+1));
        //System.out.println(numToNested.subList(0,i+1));
        //System.out.println(tempArg);
    }
    //System.out.println(numToNested.get(i));
    for(int j=0;j<numList.get(numList.size()-1);j++)
    {
        if((argList.get(j)).toString().toLowerCase().startsWith("\"suppose"))
        {
                sup.add(argList.get(j).toString());
        }
    }
    }
    return sup;
}

    public static boolean validateStructure(ArrayList<Object> theorem)
    {
        boolean valid=true;
        int theoremLength = getArgLength(theorem.get(2));
        for(int lineNumber=1;lineNumber<=theoremLength;lineNumber++)
        {
            List<String> justList = getJustifications((ArrayList<Object>)theorem.get(2),lineNumber);
            List<String> suppositionsPresentLine=suppositionsInForce((ArrayList<Object>)theorem.get(2), lineNumber);
            if(!justList.isEmpty())
            {
                for(String x : justList)
                {
                    if(Integer.parseInt(x)>=lineNumber)
                    {
                        valid=false;
                    }
                    
                    List<String> suppositionsX=suppositionsInForce((ArrayList<Object>)theorem.get(2), Integer.parseInt(x));
                    if(!suppositionsPresentLine.containsAll(suppositionsX))
                        valid=false;
                }
            }
        }
        return valid;
    }
    
    public static ArrayList<String> getPremises(ArrayList<Object> theo)
    {
        int argLength = getArgLength(theo.get(2));
        StringBuffer premiseString ;
        ArrayList<String> premises=new ArrayList<>();
        for(int i=1;i<=argLength;i++)
        {
            premiseString = getPremisesArg((ArrayList<Object>)theo.get(2),i);
            //System.out.println("premise "+premiseString);
            premises.add(premiseString.toString());
        }
        
        premiseString = new StringBuffer("( ");
        
                    ArrayList<Object> suppList = suppositionsOf((ArrayList<Object>)theo.get(2));
          //          System.out.println("suppList "+suppList);
                    for(Object sup : suppList)
                    {
                        premiseString.append(sup);
                        premiseString.append(" & ");
                    }
                    if(!suppList.isEmpty())
                    {
                        String subString =premiseString.substring(0, premiseString.length()-3);
                        premiseString = new StringBuffer(subString);
                    }
                    premiseString.append(" => ");
                    Object lastLineStr = ((List<Object>)theo.get(2)).get(((List<Object>)theo.get(2)).size()-1);
                    
                    premiseString.append(((List<Object>)lastLineStr).get(1));
                    premiseString.append(") ");
                    premiseString.append(" => ");
                    premiseString.append(theo.get(1));
                    //System.out.println("last ="+premiseString);
                    premiseString.append("\t-------------Outer Theorem");
                    premises.add(premiseString.toString());
                    return premises;
    }
    
    public static StringBuffer getPremisesArg(ArrayList<Object> arg,int lineNumber)
    {
        Object lineStr = index(arg, lineNumber);
        StringBuffer premiseString = new StringBuffer();
        if (lineStr.toString().toLowerCase().startsWith("\"suppose")) 
        {
            //System.out.println("No premises!!");
            return new StringBuffer();
        }
        else
        {
             if ( lineStr.toString().toLowerCase().startsWith("[\"a\"")) 
            {
                List<String> justList = getJustifications(arg, lineNumber);
                premiseString = getJustificationString(arg,justList);
                if(!(premiseString.length()==0)) 
                    premiseString.append(" => ");
                premiseString.append(((ArrayList<Object>)index(arg,lineNumber)).get(1));
                premiseString.append("\t---------------Line "+(lineNumber));
            }
            else
            {
                    
                    ArrayList<Integer> numList = getNumberToNested(arg, lineNumber);
                    //int argIndex = numList.get(numList.size()-1) ;
                    
                    /*System.out.println("arg.getindex "+arg.get(argIndex));
                    System.out.println("numlist="+numList);
                    System.out.println("argIndex ="+argIndex);*/
                    //Object argList =arg.get(argIndex);
                    Object argList = indexNested(arg, numList.subList(0, numList.size()-1));
                    //System.out.println("argList "+argList);
                    premiseString.append("( ");
                    ArrayList<Object> suppList = suppositionsOf((List<Object>)(((List<Object>)argList).get(2)));
          //          System.out.println("suppList "+suppList);
                    for(Object sup : suppList)
                    {
                        premiseString.append(sup);
                        premiseString.append(" & ");
                    }
                    if(!suppList.isEmpty())
                    {
                        String subString =premiseString.substring(0, premiseString.length()-3);
                        premiseString = new StringBuffer(subString);
                        premiseString.append(" => ");
                    }
                    
                    Object lastLineStr = ((List<Object>)((List<Object>)argList).get(2)).get(((List<Object>)((List<Object>)argList).get(2)).size()-1);
                    
                    premiseString.append(((List<Object>)lastLineStr).get(1));
                    premiseString.append(") ");
                    premiseString.append(" => ");
                    premiseString.append(index(arg,lineNumber));
                    premiseString.append("\t---------------Line "+(lineNumber));
            }
            
        }
        return premiseString;
    }
    public static StringBuffer getJustificationString(ArrayList<Object> arg,List<String> justList)
    {
        StringBuffer buffer = new StringBuffer();
        //System.out.println(justList);
        for(String just : justList)
        {
            Object tempStr = index(arg, Integer.parseInt(just));
            if(tempStr.toString().startsWith("[\"a\""))
            {
                buffer.append(((List<Object>)tempStr).get(1));
            }
            else
                buffer.append(tempStr);
            
            buffer.append(" & ");
        }
        if(!justList.isEmpty())
            {
                String subString =buffer.substring(0, buffer.length()-3);
                buffer = new StringBuffer(subString);
        }
        //System.out.println("buffer "+buffer);
        return buffer;
    }
    
    public static void makeFile(ArrayList<Object> theorem, boolean valid, List<String> premises)
    {
        try
        {
            FileOutputStream fop=new FileOutputStream("C:\\Logics\\Logics.txt",false);
            fop.write(("Theorem : "+theorem.get(1).toString()+"\n").getBytes());
            fop.write(("Proof :\n").getBytes());
            for(int i=1;i<=getArgLength(theorem.get(2));i++)
            {
                    fop.write(((i)+"\t").getBytes());
                    for(int x:getNumberToNested((ArrayList<Object>)theorem.get(2), i))
                        fop.write("\t".getBytes());
                fop.write((((Object)index((ArrayList<Object>)theorem.get(2),i)).toString()+"\n").getBytes());
            }
            fop.write(("\nStructural validity : "+valid).getBytes());
            if(valid)
            {
                fop.write(("\nPremises : \n").getBytes());
                for(String premise:premises)
                    if(premise.length()!=0)
                        fop.write((premise+"\n").getBytes());
            }
            fop.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
