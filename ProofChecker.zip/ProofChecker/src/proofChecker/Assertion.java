/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proofChecker;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Rishmit
 */
public class Assertion 
{
    private ArrayList<Object> assertion;

    public Assertion() {
        assertion = new ArrayList<Object>(3);
    }
    public Assertion(String type,String statement, List<String> justification) {
        assertion = new ArrayList<Object>(3);
        assertion.add(type);
        assertion.add(statement);
        assertion.add(justification);
    }
    public ArrayList<Object> getAssertion()
    {
        return assertion;
    }

    @Override
    public String toString() {
        return assertion.toString() ;
    }
         
    
}
