/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proofChecker;

import java.util.Arrays;

/**
 *
 * @author Rishmit
 */
public class Tokenizer 
{
    public final static int REMOVE_FIRST_CHAR = 1;
    public static int counter;
  /*
    getTokens() method is similar to the tokens(S) which gets TokenizedString object which contains the string message 
    tokens(S):
        tokens = []
            remove all initial white space from S,
        while S is not empty
            remove all initial white space from S,
            (token,Flag) := munch(S)
            if Flag:
                tokens := tokens + [token]
            else
                return (tokens,True)
        return (None,False)
    */  
  public static TokenizedString getTokens(TokenizedString mg)
  {
      //char[] tempMsg = mg.getStr().trim().toCharArray();
      String str = mg.getStr();
      System.out.println("1. getTokens IN");
      if(str!=null)
      {
          //int i=0;
          while(str.length()>0 )
          {
              //str = String.valueOf(Arrays.copyOfRange(str, i, str.length()+1)).trim();
              str = str.trim();
              counter=0;
              //System.out.println("2. str Msg="+str);
              String token = munch(str);
              
              if(token!=null && token.length()>0 )
              {
                 // System.out.println("8. -------------------------token: "+token);
                  mg.addTokens(token);
                  str=str.substring(counter);
              }
              
          }
          
      }
      System.out.println("getTokens OUT");
      return mg;
  }
  /*
    munch(S):
      chars := [],
      state := 'empty',
      while S is not empty and canPush(head(S),state):
      remove the first character of S and add it to the \end of chars,

      state := newState(state,c)
      if validToken(state): return (charsToTok(chars), True))
      else: return(None,False)
  */
   private static String munch(String str)
  {
    StringBuffer token = new StringBuffer();
    
      //System.out.println("3. munch IN");
    int state = TokenizerState.EMPTY;
    String firstChar =null;
    while(str.length()>0 && canPush(str.subSequence(0, 1),state))
    {
        
        state = newState(state,str.substring(0, 1));
        firstChar = str.substring(0, 1);
        str = str.substring(REMOVE_FIRST_CHAR);
        counter++;
        //System.out.println("6. munch inside and state: "+str+state);
        token.append(firstChar);
        
    }
    if(state!=TokenizerState.INVALID_STATE)
        {
            if(TokenizerState.checkValidityOfState(state))
            {
                //System.out.println("9. munch token: "+token);
                return new String(token);
            }
            
        }
    
    return null;
  }
   
   private static boolean canPush(CharSequence c,int state)
   {
       return TokenizerState.checkValidityOfChar(c,state);
   }
   
   private static int newState(int currentState, String c)
   {
       //System.out.println("6. new state"+currentState+c);
       return TokenizerState.getNewState(currentState, c);
   }
}
