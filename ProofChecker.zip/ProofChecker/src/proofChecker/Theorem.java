/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proofChecker;

import java.util.ArrayList;

/**
 *
 * @author Rishmit
 */
public class Theorem {
    
    private ArrayList<Object> theorem;

    public Theorem() {
        theorem = new ArrayList<Object>(3);
    }
    public Theorem(String type,String statement, ArrayList<Object> argument) {
        theorem = new ArrayList<Object>(3);
        theorem.add(type);
        theorem.add(statement);
        theorem.add(argument);
    }

    public ArrayList<Object> getTheorem() {
        return theorem;
    }

    public void setTheorem(ArrayList<Object> theorem) {
        this.theorem = theorem;
    }

    @Override
    public String toString() {
        return  theorem.toString();
    }
    
    
    
    
}
