/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proofChecker;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Rishmit
 */
public class ProofAssistanceClass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        String testcase1_basic = "(\"t\"  \"The class of all set which are not members of themselves is not a set.\"  (\"Suppose the class of all sets which are not members of themselves is a set.\" (\"a\" \"Let C be the set of all sets which are not members of themselves.\" (1)) (\"a\" \"C in C => not C in C\" (2))(\"a\" \"not C in C => C in C\" (2)) (\"a\" \"contradiction\" (3 4))))";
        String testcase2_complex="(\"t\"  \"If m and n are integers and k is a nonnegative integer, then mk mod n= n mod m)mod mmod m.\"(  \"suppose n is an integer\"   (\"a\" \"n mod 3 is either 0,1, or 2\" ( ) ) (\"t\"  \"If n mod 3 = 0 then not n^2 mod 3=2\"  (     \"Suppose n mod 3 = 0.\"(\"a\" \"n^2 mod 3   = (n mod 3)^2 mod 3\" () ) (\"a\"              \"= 0^2mod 3 \" ( 4 ) )(\"a\"             \"= 0\" ( ) ) (\"a\" \"n mod 3 =0\" ( ) )  ))(\"t\" \"f n mod 3 = 1 then not n^2 mod 3 = 2\"  (  \"Suppose n mod 3 = 1.\"( \"a\"  \"n^2 mod 3  = (n mod 3)^2 mod 3\" ( ) ) ( \"a\"  \"              = n^2 mod 3\"   (10) ) (  \"a\"      \"         = 1   n^2 mod 3 = 1\" ( ) )    ))(\"t\"  \"If n mod 3 = 2 then not n^2 mod 3=2\"  ( \"Suppose n mod 3 = 2.\"(\"a\"  \" n^2 mod 3 = (n mod 3)2 mod 3 \" ( ) )(\"a\"   \"            = 2^2mod 3\"  (15) )(\"a\"  \"              = 4 mod 3\" ( ) )(\"a\"   \"            = 1\" ( ) ) (\"a\"  \" n^2 mod 3 = 1\" ( ) )  )) (\"a\"  \"n mod 3 not= 2\" (2 3 9 14))) )";
        //String str2="(\"t\" \"The class of all set which are not members of themselves is not a set.\" (\"Suppose the class of all sets which are not members of themselves is a set.\" (\"a\" \"Let C be the set of all sets which are not members of themselves.\" (1)) (\"t\" \"The class of all set which are not members of themselves is not a set.\" ( \"Suppose the class of all sets which are not members of themselves is a set.\" (\"a\" \"Let C be the set of all sets which are not members of themselves.\" (1))(\"a\" \"Let C be the set of all sets which are not members of themselves.\" (1))))(\"t\" \"The class of all set which are not members of themselves is not a set.\" ( \"Suppose the class of all sets which are not members of themselves is a set.\" (\"a\" \"Let C be the set of all sets which are not members of themselves.\" (1))(\"a\" \"Let C be the set of all sets which are not members of themselves.\" (1))))))";
        //String str3="(\"t\" \"The class of all set which are not members of themselves is not a set.\" (\"Suppose the class of all sets which are not members of themselves is a set.\" (\"a\" \"Let C be the set of all sets which are not members of themselves.\" (1)) (\"t\" \"The class of all set which are not members of themselves is not a set.\" ( \"Suppose the class of all sets which are not members of themselves is a set.\" (\"a\" \"Let C be the set of all sets which are not members of themselves.\" (2)) (\"a\" \"Let C be the set of all sets which are not members of themselves.\" (3))(\"a\" \"Let C be the set of all sets which are not members of themselves.\" (4))(\"t\" \"The class of all set which are not members of themselves is not a set.\" (\"Suppose the class of all sets which are not members of themselves is a set.\" (\"a\" \"Let C be the set of all sets which are not members of themselves.\" (5))))(\"a\" \"Let C be the set of all sets which are not members of themselves.\" (6))(\"a\" \"Let C be the set of all sets which are not members of themselves.\" (7))))))";
        String testcase3_finalStr="(\"t\" \"All bears are blue\"( \"Suppose x is a bear\"(\"t\" \"x is neat\"( \"Suppose x is not neat\"(\"a\" \"x is not clean\" (3))(\"a\" \"x is not a bear\" (4))(\"a\" \"contradiction\" (1 5))))(\"a\" \"x is cool\" (1 2))(\"a\" \"x is blue\" (7))))";
        TokenizedString mg = new TokenizedString();
        //change the variable name to the required test case name
        mg.setStr(testcase1_basic);
        TokenizedString resultMsg = Tokenizer.getTokens(mg);
        System.out.println("Tokens: "+String.valueOf(resultMsg.getTokens()));
        Parser.parseTheorem(resultMsg.getTokens());
        Parser parser = new Parser();
        ArrayList<Object> parsedTheorem = Parser.parseTheorem(resultMsg.getTokens());

        boolean validity = Parser.validateStructure(parsedTheorem);
        List<String> premises = null;
        if(Parser.validateStructure(parsedTheorem))
            premises = Parser.getPremises(parsedTheorem);
        Parser.makeFile(parsedTheorem, validity, premises);
    }
    
}
