/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proofChecker;

import java.util.ArrayList;

/**
 *
 * @author Rishmit
 */
public class TokenizedString 
{
    private String str;
    private boolean status;//whether tokenizer was successful or not, by default it will be false
    private ArrayList<String> tokens;

    //By default status of converstion of message is FALSE and will alter while processing
    public TokenizedString() {
    this.status = false;
    tokens = new ArrayList<String>();
    }

    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public ArrayList<String> getTokens() {
        return tokens;
    }

    public void setTokens(ArrayList<String> tokens) {
        this.tokens = tokens;
    }

    public void addTokens(String token)
    {
        tokens.add(token);
    }
    
    
}
