/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proofChecker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Rishmit
 */
public class TokenizerState 
{
    public static final int EMPTY = 1;
    public static final int NUMERAL = 2;
    public static final int PARTIAL_STRING = 3;
    public static final int WHOLE_STRING = 4;
    public static final int PAREN = 5;
    public static final int INVALID_STATE = -1;
    
    public static final Map<Integer,String> characterMap;
    public static final Map<Integer,Map<String,Integer>> transitionTable;
    
    static
    {
        //Initialize characterMap with valid characters
        characterMap = new Hashtable<Integer,String>();
        characterMap.put(EMPTY, "[\\d\"()]");
        characterMap.put(NUMERAL, "\\d");
        characterMap.put(PARTIAL_STRING, ".");
        characterMap.put(WHOLE_STRING,"");
        characterMap.put(PAREN,"");
        
        //Initialize transitiontable with valid characters
        transitionTable = new Hashtable<Integer,Map<String,Integer>>();
        Map<String,Integer> innerMap1 = new Hashtable<String,Integer>();
        innerMap1.put("[0-9]",NUMERAL);
        innerMap1.put("\"", PARTIAL_STRING);
        innerMap1.put("[()]", PAREN);
        transitionTable.put(EMPTY,innerMap1);
        
        Map<String,Integer> innerMap2 = new Hashtable<String,Integer>();
        innerMap2.put("[0-9]",NUMERAL);
        transitionTable.put(NUMERAL,innerMap2);
        
        Map<String,Integer> innerMap3 = new Hashtable<String,Integer>();
        innerMap3.put("[^\"]", PARTIAL_STRING);
        innerMap3.put("[\"]",WHOLE_STRING);
        transitionTable.put(PARTIAL_STRING,innerMap3);
        
    }
    public static boolean checkValidityOfState(int state)
    {
        boolean valid =false;
        if(state==1 || state ==2 || state==4 || state==5)
            valid=true;
        return valid;
    }
    
    public static boolean checkValidityOfChar(CharSequence c, int state)
    {
        boolean status = false;
        String regex = characterMap.get(state);
        //System.out.println("4. regex: "+regex);
        if(regex==null)
            status=true;
        else
        if(regex.length()!=0)
        {
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(c);
            if(m.matches())
                status = true;
        }
        //System.out.println("5. checkValidityOfChar :"+status);
        return status;
    }
    
    public static int getNewState(int currentState, String c)
    {
        int newState = currentState;
        
        if(currentState>=1 && currentState<=5)
        {
            Map<String,Integer> mapEntry = transitionTable.get(currentState);
            Iterator<Map.Entry<String,Integer>> iterator = mapEntry.entrySet().iterator();
            while(iterator.hasNext())
            {
               Map.Entry<String,Integer> entry = iterator.next();
               String key = entry.getKey();
               if(c.matches(key))
               {
                   newState = entry.getValue();
                   //System.out.println("key "+key);
                    //System.out.println("7. getnewstate"+newState+c);
                   return newState;
               }
            }
            
        }
        return newState;
    }
}
